#include <pbc/pbc.h>
#include <pbc/pbc_test.h>
#include <string.h>
int main(int argc, char **argv)
{
	pairing_t pairing;
	//double time1, time2;

	element_t pkgs;
	element_t Q, S;

	FILE *fpr = NULL, *fpw = NULL;
	const char *param, *pkgs_data, *fdata;
	size_t count;
	size_t result;
	unsigned char *identity = "server@mail.com";
	size_t id_len = strlen(identity);
	size_t S_len;
	int curr, fillen, flen = 0, t = 0;
	char type[9];
	size_t test;

	//read param and pkgs
	if(!(fpr = fopen("192.param", "r")))
	{
		printf("File Open ERROR!\n");
		return 0;
	}

	//read file
	while(fscanf(fpr, "%s", type) != EOF)
	{
		printf("type = %s: \n", type);
		if(strcmp(type, "pairing") == 0)
			t = 1;
		else if(strcmp(type, "s") == 0)
			t = 2;
		else {
			printf("File Read ERROR!\n");
			return 0;
		}

		fgetc(fpr);
		if(fscanf(fpr, "%d", &flen) == EOF)
		{
			printf("File Read ERROR!\n");
			return 0;
		}
		printf("flen = %d\n", flen);
		fgetc(fpr);

		fdata = (char *)malloc(sizeof(char) *(flen + 1));
		memset(fdata, '\0', sizeof(char) *(flen + 1));
		if(!(test = fread(fdata, 1, flen, fpr)))
		{
			printf("File Read Error!\n");
			return 0;
		}
		printf("Num of read fdata = %d\n", test);
		printf("fdata = %s\n", fdata);

		switch (t)
		{
			case 1:
				param = fdata;
				count = flen;
				printf("count = %d\n", count);
				break;
			case 2:
				pkgs_data = fdata;
				break;
		}
		
		memset(type, '\0', 9);
		flen = 0;
	}
	fclose(fpr);
	
	//generate pkg param
	pairing_init_set_buf(pairing, param, count);
	// Is symmetric pairing?
	if(!pairing_is_symmetric(pairing))
	{
		printf("Not symmetric pairing!\n");
		return 0;
	}	

	element_init_G1(Q, pairing);
	element_init_G1(S, pairing);
	element_init_Zr(pkgs, pairing);

	element_from_hash(Q, identity, id_len);
	element_set_str(pkgs, pkgs_data, 10);
	element_mul_zn(S, Q, pkgs);

	//print element for test
	element_printf("pkgs = %B\n", pkgs);
	element_printf("Q = %B\n", Q);
	element_printf("S = %B\n", S);

	//start write file
	if(!(fpw = fopen("server_192.id", "w")))
	{
		element_clear(Q);
		element_clear(S);
		element_clear(pkgs);
		pairing_clear(pairing);
		printf("File Open ERROR!\n");
		return 0;
	}

	//write ID
	if(fputs("ID ", fpw) == EOF)
	{
		printf("File write error!\n");
		return 0;
	}
	if(fprintf(fpw, "%d ", id_len) < 0)
	{
		printf("File write error!\n");
		return 0;
	}
	if(fputs(identity, fpw) == EOF)
	{
		printf("File write error!\n");
		return 0;
	}
	//write s
	if(fputc('\n', fpw) == EOF)
	{
		printf("File write error!\n");
		return 0;
	}
	curr = ftell(fpw);

	result = element_out_str(fpw, 10, S);
	printf("Num of write S = %d.\n", result);

	fseek(fpw, 0L, SEEK_END);
	fillen = (int)ftell(fpw) - curr;
	printf("fillen = %d.\n", fillen);

	element_clear(Q);
	element_clear(S);
	element_clear(pkgs);
	pairing_clear(pairing);
	fclose(fpw);
	return 0;
}
