/* stack.h for openssl */

